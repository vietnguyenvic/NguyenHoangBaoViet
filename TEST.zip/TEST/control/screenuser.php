<?php 

    class Screenuser
    {
       
        public function index()
        {
         
            include "view/screenuser.php"; 
        }
    
    }
  
?>